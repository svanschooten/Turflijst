#!/bin/bash

sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 7F0CEB10
echo "deb http://repo.mongodb.org/apt/ubuntu "$(lsb_release -sc)"/mongodb-org/3.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.0.list
sudo apt-get update

sudo npm install -g browserify less clean-css uglify-js zip

sudo npm install

if [[ $1 == "remote" ]]
	then
	echo "now create the remote database:"
	echo "	database turflijst"
	echo "	collection turfs"
else
	sudo apt-get install -y mongodb-org

	sudo service mongod start

	echo "now create the database:"
	echo "	mongo"
	echo "	use turflijst"
	echo "	db.turfs.insert({})"
fi
